#!/bin/bash
flask --app server run
